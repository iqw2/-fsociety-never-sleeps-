FSOCIETY | RED TIGER TOOLKIT
=============================

Windows / Visual Studio Code
----------------------------
1. ZIP-Datei entpacken.
2. Den Ordner "red_tiger" in Visual Studio Code öffnen.
3. Terminal > Neues Terminal öffnen.
4. Im Terminal ausführen:

   py red_tiger.py

Falls "py" nicht funktioniert:

   python red_tiger.py

Voraussetzungen
---------------
- Python 3.10 oder neuer empfohlen
- Keine zusätzlichen Python-Pakete erforderlich
- Internetzugang für öffentliche IP-/URL-/TLS-/Profil-Abfragen
- Für lokale Dateianalyse den Pfad zur Datei eingeben

Enthaltene Kernwerkzeuge
------------------------
01 Deep IP Intelligence: DNS-Auflösung, PTR, IP-Klassifizierung,
   öffentliches Geo-/ASN-/Netzwerk- und RDAP-Registerprofil.
02 URL Deep Audit: URL-Parsing, DNS/IP/PTR, HTTP-Status, Antwortzeit,
   Header, wichtige Security-Header, HTML-Metadaten und bekannte
   öffentliche Well-Known-Dateien; ergänzt um TLS-Details bei HTTPS.
03 TLS / Certificate Inspector: TLS-Version, Cipher, Zertifikat,
   Subject, Issuer, Laufzeit und SAN.
04 DNS / Reverse DNS: A-/AAAA-Auflösung und PTR.
05 Public Username Presence Check: öffentliche Profil-URLs bei
   ausgewählten Plattformen; keine privaten Daten oder Identitätsfeststellung.
06 File Hash / Entropy / Static Indicators: MD5/SHA-Hashes, Byte-Entropie
   und einfache statische Textindikatoren; Datei wird nicht ausgeführt.
07 Local Network Snapshot: lokale Host-/Netzwerkdaten.
08 Localhost Port Check: begrenzter TCP-Portcheck ausschließlich auf
   Loopback (127.0.0.1 / ::1).
09 IP / CIDR Calculator: IPv4-/IPv6- und Netzwerkdetails.
10 Email Header Analyzer: .eml-Header, Received-Kette und Auth-Ergebnisse.
11 HTTP Security Header Check: Header eines HTTP(S)-Endpunkts.

Hinweise
--------
- Ausschließlich eigene Systeme oder Ziele mit ausdrücklicher Erlaubnis prüfen.
- Das Tool ist bewusst passiv/defensiv: keine Exploits, Brute-Force-Versuche,
  DDoS, Malware-Erstellung, Credential-Diebstahl, RATs oder Umgehung von
  Login-/Rate-Limit-/Privatsphäre-Schutz.
- Öffentliche Datenquellen können ausfallen, Daten verzögert liefern oder
  Anfragen begrenzen. HTTP-Statuscodes bei Profilen sind kein sicherer
  Nachweis, ob ein Benutzername vergeben ist.
- IP-Geolokalisierung ist näherungsweise und keine verlässliche
  Standortbestimmung einer Person.
- Die Ergebnisse sind technische Hinweise, kein vollständiger
  Sicherheitsnachweis oder Ersatz für einen autorisierten Pentest.

Design
------
Terminal-UI mit dunkler Darstellung, roter FSOCIETY-Überschrift,
TOOLKIT-Untertitel und nummeriertem Menü.
