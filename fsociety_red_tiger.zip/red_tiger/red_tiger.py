#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FSOCIETY | RED TIGER
Passive cyber-security reconnaissance & defensive analysis toolkit.
Only use against systems and accounts you own or are explicitly authorized to assess.
"""
import os, sys, re, json, ssl, socket, hashlib, ipaddress, urllib.request, urllib.parse
import urllib.error, html, math, time, platform, getpass
from datetime import datetime
from email import policy
from email.parser import BytesParser

R="\033[91m"; D="\033[31m"; W="\033[97m"; C="\033[96m"; G="\033[92m"; Y="\033[93m"; M="\033[95m"; Z="\033[0m"; B="\033[1m"
UA="FSOCIETY-RED-TIGER/1.0 (passive-security-audit; contact: local-user)"
TIMEOUT=12

def clear():
    os.system("cls" if os.name=="nt" else "clear")

def banner():
    print(R+B+r"""
  ______ ____   ____   _____ ___ _____ _____ _______   __
 |  ____/ __ \ / __ \ / ____|_ _/ ____|_   _|__   __| / /
 | |__ | |  | | |  | | (___  | | |      | |    | |   / /
 |  __|| |  | | |  | |\___ \ | | |      | |    | |  / /
 | |   | |__| | |__| |____) || | |____ _| |_   | | / /___
 |_|    \____/ \____/|_____/___\_____|_____|  |_|/_____/
"""+Z)
    print(C+B+"                         T O O L K I T"+Z)
    print(D+"       PASSIVE RECON  •  OSINT  •  WEB AUDIT  •  FORENSICS"+Z)
    print(W+"       Authorized assessments only | No exploitation / brute force"+Z)
    print(D+"-"*78+Z)

def section(title):
    print("\n"+D+"╔"+"═"*76+"╗"+Z)
    print(D+"║ "+W+B+title[:72].ljust(72)+Z+D+" ║"+Z)
    print(D+"╚"+"═"*76+"╝"+Z)

def ask(prompt):
    return input(C+"[?] "+prompt+Z+" ").strip()

def pause():
    input(Y+"\n[ENTER] zurück zum Menü..."+Z)

def req(url, method="GET", headers=None, max_bytes=180000):
    h={"User-Agent":UA, "Accept":"*/*"}
    if headers: h.update(headers)
    request=urllib.request.Request(url, headers=h, method=method)
    with urllib.request.urlopen(request, timeout=TIMEOUT, context=ssl.create_default_context()) as r:
        body=r.read(max_bytes)
        return r.status, r.geturl(), dict(r.headers.items()), body

def safe_host(value):
    value=value.strip()
    if "://" in value: value=urllib.parse.urlsplit(value).hostname or ""
    value=value.split("/")[0].split(":")[0].strip().strip(".")
    if not value or any(ch.isspace() for ch in value): raise ValueError("Ungültiger Hostname.")
    return value.encode("idna").decode("ascii")

def print_json(obj, indent=0, limit=6000):
    s=json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    print(s[:limit] + ("\n… (gekürzt)" if len(s)>limit else ""))

def resolve(host):
    try:
        infos=socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
        return sorted(set(i[4][0] for i in infos))
    except Exception as e:
        return ["Auflösung fehlgeschlagen: "+str(e)]

def ip_lookup():
    section("01 | DEEP IP INTELLIGENCE")
    raw=ask("IP-Adresse oder Hostname:")
    try:
        host=safe_host(raw)
        ips=resolve(host)
        if ips and ips[0].startswith("Auflösung"): print(Y+ips[0]+Z); return
        print(G+"[+] Ziel: "+host+Z)
        for ip in ips:
            print("\n"+B+C+"IP: "+ip+Z)
            try:
                obj=ipaddress.ip_address(ip)
                print("Typ:", "IPv4" if obj.version==4 else "IPv6",
                      "| global:",obj.is_global,"| privat:",obj.is_private,
                      "| reserviert:",obj.is_reserved,"| loopback:",obj.is_loopback)
            except Exception: pass
            try:
                ptr=socket.gethostbyaddr(ip)
                print("Reverse DNS:",ptr[0],"| Aliase:",ptr[1])
            except Exception as e: print("Reverse DNS: nicht verfügbar ("+str(e)+")")
            if ipaddress.ip_address(ip).is_global:
                for label,url in [("IPWHOIS / GEO / ASN","https://ipwho.is/"+urllib.parse.quote(ip)),
                                  ("RDAP / REGISTRIERUNG","https://rdap.org/ip/"+urllib.parse.quote(ip))]:
                    print("\n"+Y+"--- "+label+" ---"+Z)
                    try:
                        _,_,_,body=req(url,headers={"Accept":"application/json"})
                        data=json.loads(body.decode("utf-8","replace"))
                        if label.startswith("IPWHOIS") and isinstance(data,dict):
                            # Preserve the provider's returned detail while avoiding huge unrelated payloads.
                            print_json(data,limit=9000)
                        else:
                            keys=("name","handle","type","country","startAddress","endAddress","ipVersion","port43","status","events","entities","remarks","links")
                            print_json({k:data.get(k) for k in keys if k in data},limit=9000)
                    except Exception as e: print(Y+"Lookup nicht verfügbar: "+str(e)+Z)
    except Exception as e: print(R+"Fehler: "+str(e)+Z)

def url_audit():
    section("02 | URL DEEP AUDIT")
    raw=ask("URL oder Domain:")
    if not raw: return
    url=raw if "://" in raw else "https://"+raw
    p=urllib.parse.urlsplit(url)
    if p.scheme not in ("http","https") or not p.hostname:
        print(R+"Nur gültige HTTP(S)-URLs."+Z); return
    host=safe_host(p.hostname)
    print(G+"[+] Normalisiert:"+Z,urllib.parse.urlunsplit((p.scheme, p.netloc or host,p.path or "/",p.query,"")))
    print("Scheme:",p.scheme,"| Host:",host,"| Port:",p.port or (443 if p.scheme=="https" else 80))
    print("Pfad:",p.path or "/","| Query:",p.query or "(keine)","| Fragment:",p.fragment or "(keines)")
    print("\n"+C+"[ DNS / IP ]"+Z)
    ips=resolve(host); print("Adressen:",", ".join(ips))
    for ip in ips:
        if not ip.startswith("Auflösung"):
            try: print(ip,"PTR:",socket.gethostbyaddr(ip)[0])
            except Exception: print(ip,"PTR: nicht gesetzt")
    print("\n"+C+"[ HTTP / RESPONSE ]"+Z)
    started=time.time()
    try:
        status,final,headers,body=req(url)
        print("Status:",status,"| Dauer:",round(time.time()-started,3),"s")
        print("Finale URL:",final,"| Content-Type:",headers.get("Content-Type","?"),
              "| Bytes gelesen:",len(body))
        print("Alle Antwort-Header:")
        for k,v in sorted(headers.items(),key=lambda x:x[0].lower()): print(" ",k+":",v)
        print("\n"+C+"[ SECURITY HEADERS ]"+Z)
        checks=["Strict-Transport-Security","Content-Security-Policy","X-Content-Type-Options",
                "X-Frame-Options","Referrer-Policy","Permissions-Policy"]
        for k in checks: print(("+" if k in headers else "-"),k,":",headers.get(k,"FEHLT"))
        print("\n"+C+"[ HTML METADATA ]"+Z)
        text=body.decode("utf-8","replace")
        title=re.search(r"<title[^>]*>(.*?)</title",text,re.I|re.S)
        desc=re.search(r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)',text,re.I)
        canon=re.search(r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']*)',text,re.I)
        print("Titel:",html.unescape(re.sub(r"\s+"," ",title.group(1)).strip()) if title else "(nicht gefunden)")
        print("Beschreibung:",html.unescape(desc.group(1)) if desc else "(nicht gefunden)")
        print("Canonical:",canon.group(1) if canon else "(nicht gefunden)")
        for name,pattern in [("Links",r"<a\b"),("Scripts",r"<script\b"),("Forms",r"<form\b"),("Images",r"<img\b")]:
            print(name+":",len(re.findall(pattern,text,re.I)))
        print("\n"+C+"[ PUBLIC WELL-KNOWN FILES ]"+Z)
        origin=p.scheme+"://"+p.netloc
        for path in ("/robots.txt","/sitemap.xml","/.well-known/security.txt"):
            try:
                st,fin,hh,bb=req(origin+path,max_bytes=12000)
                print(path,"=>",st,"|",hh.get("Content-Type","?"),"|",len(bb),"Bytes")
                if path.endswith("security.txt") and st==200: print(bb.decode("utf-8","replace")[:1800])
            except urllib.error.HTTPError as e: print(path,"=> HTTP",e.code)
            except Exception as e: print(path,"=> nicht abrufbar:",e)
    except urllib.error.HTTPError as e:
        print("HTTP-Fehler:",e.code,e.reason)
        for k,v in e.headers.items(): print(k+":",v)
    except Exception as e: print(R+"Abruf fehlgeschlagen: "+str(e)+Z)
    if p.scheme=="https": tls_check(host,p.port or 443,quiet=True)

def tls_check(host=None,port=443,quiet=False):
    if not quiet: section("03 | TLS / CERTIFICATE INSPECTOR"); host=safe_host(ask("Hostname:"))
    try:
        ctx=ssl.create_default_context()
        with socket.create_connection((host,port),timeout=TIMEOUT) as sock:
            with ctx.wrap_socket(sock,server_hostname=host) as s:
                cert=s.getpeercert()
                print(G+"TLS-Verbindung erfolgreich"+Z,"| Version:",s.version(),"| Cipher:",s.cipher())
                print("Subject:",cert.get("subject"))
                print("Issuer:",cert.get("issuer"))
                print("Gültig ab:",cert.get("notBefore"),"| bis:",cert.get("notAfter"))
                print("SAN:",cert.get("subjectAltName"))
                print("ALPN:",s.selected_alpn_protocol())
    except Exception as e: print(Y+"TLS-Check: "+str(e)+Z)

def dns_lookup():
    section("04 | DNS / REVERSE DNS")
    host=safe_host(ask("Domain oder IP:"))
    try:
        ip=ipaddress.ip_address(host)
        print("IP-Typ:",ip.version,"| privat:",ip.is_private,"| global:",ip.is_global)
        try: print("PTR:",socket.gethostbyaddr(host))
        except Exception as e: print("PTR nicht verfügbar:",e)
    except ValueError:
        for family,label in [(socket.AF_INET,"A / IPv4"),(socket.AF_INET6,"AAAA / IPv6")]:
            try:
                vals=sorted(set(x[4][0] for x in socket.getaddrinfo(host,None,family,socket.SOCK_STREAM)))
                print(label+":",", ".join(vals) if vals else "(keine)")
            except Exception as e: print(label+":",e)
        print("Hinweis: Die Standardbibliothek liefert hier A/AAAA; MX/TXT/NS benötigen einen DNS-Resolver oder DoH.")

def username_check():
    section("05 | PUBLIC USERNAME PRESENCE CHECK")
    name=ask("Öffentlicher Benutzername (keine Passwörter):")
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,40}",name):
        print(R+"Erlaubt: 1–40 Zeichen A-Z, 0-9, Punkt, Unterstrich, Bindestrich."+Z); return
    sites={
      "GitHub":"https://github.com/"+name,
      "GitLab":"https://gitlab.com/"+name,
      "Reddit":"https://www.reddit.com/user/"+name+"/",
      "Mastodon.social":"https://mastodon.social/@"+name,
      "YouTube":"https://www.youtube.com/@"+name,
      "Twitch":"https://www.twitch.tv/"+name,
      "TikTok":"https://www.tiktok.com/@"+name,
      "Instagram":"https://www.instagram.com/"+name+"/"
    }
    print(Y+"Prüft nur öffentlich erreichbare Profil-URLs per HTTP; Statuscodes sind kein sicherer Existenzbeweis."+Z)
    for site,url in sites.items():
        try:
            reqobj=urllib.request.Request(url,headers={"User-Agent":UA,"Accept":"text/html,*/*"},method="GET")
            with urllib.request.urlopen(reqobj,timeout=8,context=ssl.create_default_context()) as r:
                code=r.status; final=r.geturl()
            result="öffentlich erreichbar" if code==200 else "Antwort "+str(code)
        except urllib.error.HTTPError as e:
            result="HTTP "+str(e.code)
        except Exception as e: result="unklar ("+str(e)[:90]+")"
        print(f"{site:18} {result:28} {url}")
    print(Y+"Keine Umgehung von Login, Rate-Limits, Sperren oder privaten Profilen; keine Identitätsfeststellung."+Z)

def file_forensics():
    section("06 | FILE HASH / ENTROPY / STATIC INDICATORS")
    path=ask("Dateipfad:")
    try:
        h={x:hashlib.new(x) for x in ("md5","sha1","sha256","sha512")}
        counts=[0]*256; total=0
        with open(path,"rb") as f:
            while True:
                chunk=f.read(1024*1024)
                if not chunk: break
                total+=len(chunk)
                for x in h.values(): x.update(chunk)
                for b in chunk:
                    counts[b]+=1
        entropy=-sum((n/total)*math.log2(n/total) for n in counts if n) if total else 0
        print("Datei:",os.path.abspath(path),"| Größe:",total,"Bytes")
        for k,v in h.items(): print(k.upper()+":",v.hexdigest())
        print("Byte-Entropie:",round(entropy,4),"von 8.0")
        with open(path,"rb") as f: sample=f.read(2_000_000).decode("latin-1","ignore")
        patterns={
          "PowerShell encoded command":r"(?i)powershell.{0,80}-(enc|encodedcommand)",
          "Windows script host":r"(?i)(wscript|cscript)\.exe",
          "Suspicious download primitive":r"(?i)(Invoke-WebRequest|DownloadString|curl\s+https?://)",
          "Shell execution":r"(?i)(cmd\.exe\s+/c|/bin/(sh|bash)|subprocess\.Popen)",
          "Credential-related strings":r"(?i)(passwords?\.txt|login data|credential dump|lsass)"
        }
        print("\nStatische String-Indikatoren (nur Hinweise, kein Malware-Nachweis):")
        found=False
        for label,pat in patterns.items():
            if re.search(pat,sample): print(Y+"[!] "+label+Z); found=True
        if not found: print(G+"Keine der einfachen Textsignaturen gefunden."+Z)
        print(Y+"Datei wurde ausschließlich gelesen; nicht ausgeführt. Entropie/Strings allein beweisen keine Schadsoftware."+Z)
    except Exception as e: print(R+"Fehler: "+str(e)+Z)

def local_network():
    section("07 | LOCAL NETWORK SNAPSHOT")
    print("System:",platform.platform(),"| Benutzer:",getpass.getuser(),"| Host:",socket.gethostname())
    try:
        for item in socket.getaddrinfo(socket.gethostname(),None):
            print("Lokale Adresse:",item[4][0])
    except Exception as e: print("Adressen:",e)
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect(("192.0.2.1",80))
        print("Ausgehende IPv4-Schnittstelle:",s.getsockname()[0]); s.close()
    except Exception as e: print("Schnittstelle:",e)
    print("Betriebssystem:",os.name,"| Python:",sys.version.split()[0])

def localhost_ports():
    section("08 | LOCALHOST PORT CHECK")
    host=ask("Ziel (nur localhost/Loopback erlaubt; Enter = 127.0.0.1):") or "127.0.0.1"
    try:
        ip=ipaddress.ip_address(host)
        if not ip.is_loopback: print(R+"Aus Sicherheitsgründen nur Loopback-Adressen."+Z); return
    except ValueError: print(R+"Bitte 127.0.0.1 oder ::1 eingeben."+Z); return
    raw=ask("Ports (z.B. 22,80,443,8000-8010):")
    ports=set()
    try:
        for part in raw.split(","):
            if "-" in part:
                a,b=map(int,part.split("-",1))
                if b<a or b-a>100: raise ValueError("Bereich maximal 101 Ports")
                ports.update(range(a,b+1))
            else: ports.add(int(part))
        if any(p<1 or p>65535 for p in ports): raise ValueError("Port außerhalb 1–65535")
    except Exception as e: print(R+"Eingabe: "+str(e)+Z); return
    for port in sorted(ports):
        try:
            with socket.create_connection((str(ip),port),timeout=0.35): print(G+f"OPEN   {port}"+Z)
        except Exception: print(D+f"CLOSED {port}"+Z)

def cidr_tool():
    section("09 | IP / CIDR CALCULATOR")
    raw=ask("IPv4/IPv6-Adresse oder Netzwerk (z.B. 192.168.1.0/24):")
    try:
        net=ipaddress.ip_network(raw,strict=False) if "/" in raw else ipaddress.ip_address(raw)
        print("Version:",net.version,"| Netzwerk:",net)
        if hasattr(net,"num_addresses"):
            print("Netzmaske:",getattr(net,"netmask","n/a"),"| Broadcast:",getattr(net,"broadcast_address","n/a"))
            print("Adressen:",net.num_addresses)
            if net.num_addresses<=65536:
                print("Erste Adresse:",net.network_address,"| Letzte:",net.broadcast_address)
    except Exception as e: print(R+"Fehler: "+str(e)+Z)

def email_header():
    section("10 | EMAIL HEADER ANALYZER")
    path=ask("Pfad zu .eml-Datei:")
    try:
        with open(path,"rb") as f: msg=BytesParser(policy=policy.default).parse(f)
        for key in ("From","To","Date","Subject","Reply-To","Return-Path","Message-ID"):
            print(f"{key:14}: {msg.get(key,'(nicht vorhanden)')}")
        print("\nReceived-Kette (in Rohreihenfolge):")
        for i,v in enumerate(msg.get_all("Received",[]),1): print(f"{i:02d}. {v}")
        print("\nAuth-Ergebnisse:")
        for v in msg.get_all("Authentication-Results",[]): print(v)
        for v in msg.get_all("Received-SPF",[]): print("SPF:",v)
        print(Y+"Header können gefälscht sein; SPF/DKIM/DMARC-Ergebnisse müssen im Kontext des empfangenden Mailservers bewertet werden."+Z)
    except Exception as e: print(R+"Fehler: "+str(e)+Z)

def http_headers():
    section("11 | HTTP SECURITY HEADER CHECK")
    raw=ask("URL/Domain:")
    url=raw if "://" in raw else "https://"+raw
    try:
        status,final,headers,body=req(url,method="HEAD")
    except Exception:
        try: status,final,headers,body=req(url)
        except Exception as e: print(R+"Fehler: "+str(e)+Z); return
    print("Status:",status,"| Finale URL:",final)
    for k,v in sorted(headers.items()): print(k+":",v)
    print("\nHeader-Bewertung:")
    for k in ("Strict-Transport-Security","Content-Security-Policy","X-Content-Type-Options","X-Frame-Options","Referrer-Policy","Permissions-Policy"):
        print(("VORHANDEN" if k in headers else "FEHLT    "),k)

def help_screen():
    section("ABOUT / SAFE USE")
    print("""FSOCIETY / RED TIGER ist ein passives Recon- und Analyse-Toolkit.
Die Funktionen sammeln öffentlich erreichbare technische Metadaten,
prüfen lokale Systeme oder analysieren Dateien rein lesend.
Es gibt absichtlich keine Exploits, Passwortversuche, DDoS-, Malware-,
Stealer-, RAT- oder Umgehungsfunktionen.
Nutze es nur für eigene Systeme oder mit ausdrücklicher Erlaubnis.
Netzwerk-Lookups benötigen Internetzugang; Ergebnisse hängen von
Drittanbietern, DNS, Netzwerk und Rate-Limits ab.
""")

TOOLS=[
("01","Deep IP Intelligence",ip_lookup),("02","URL Deep Audit",url_audit),
("03","TLS / Certificate Inspector",tls_check),("04","DNS / Reverse DNS",dns_lookup),
("05","Public Username Presence Check",username_check),("06","File Hash / Entropy / Static Indicators",file_forensics),
("07","Local Network Snapshot",local_network),("08","Localhost Port Check",localhost_ports),
("09","IP / CIDR Calculator",cidr_tool),("10","Email Header Analyzer",email_header),
("11","HTTP Security Header Check",http_headers),("12","About / Safe Use",help_screen)
]

def menu():
    while True:
        clear(); banner()
        print(D+B+"  [ RECON & INTELLIGENCE ]"+Z)
        for i in range(0,4):
            print(f"   {TOOLS[i][0]}  {W}{TOOLS[i][1]}{Z}")
        print("\n"+D+B+"  [ ANALYSIS & DEFENSE ]"+Z)
        for i in range(4,len(TOOLS)):
            print(f"   {TOOLS[i][0]}  {W}{TOOLS[i][1]}{Z}")
        print("\n"+D+"─"*78+Z)
        choice=ask("Toolnummer wählen (Q = Beenden):").lower()
        if choice in ("q","quit","exit"): print(R+"FSOCIETY offline."+Z); break
        match=next((t for t in TOOLS if t[0]==choice.zfill(2)),None)
        if not match: print(Y+"Unbekannte Auswahl."+Z); time.sleep(0.8); continue
        clear(); banner()
        try: match[2]()
        except KeyboardInterrupt: print(Y+"\nAbgebrochen."+Z)
        except Exception as e: print(R+"Unerwarteter Fehler: "+str(e)+Z)
        pause()

if __name__=="__main__":
    try: menu()
    except KeyboardInterrupt: print("\nBeendet.")
